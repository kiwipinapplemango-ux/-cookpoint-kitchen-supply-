# Cookpoint Kitchen Supply LLC website starter

## Included
- Responsive luxury/professional storefront in black, white, and orange
- Home, product catalog, About, and Contact sections
- Category filters, add-to-cart, quantity controls, subtotal
- Stripe Checkout backend starter (requires your Stripe account and secret key)
- Sample product names and prices for demonstration

## Run locally
1. Install Node.js (18+).
2. In this folder run: `npm install`
3. Copy `.env.example` to `.env`.
4. Add your Stripe secret key and site URL to `.env`.
5. Run: `npm start`
6. Visit `http://localhost:4242`

## Before publishing
- Replace the temporary text logo with your official Cookpoint logo file.
- Confirm product names, prices, photos, inventory, shipping, tax, and return policies.
- Replace the contact placeholders in `public/index.html`.
- In `public/app.js`, replace `REPLACE_WITH_YOUR_EMAIL` with the inbox that should receive inquiries.
- Configure Stripe in `.env`. Test in Stripe test mode before accepting live payments.
- Deploy the Node app to a host that supports server-side Node.js and HTTPS.
- Add privacy policy, terms, shipping, and returns pages appropriate to your business.

## Payment note
The cart works in the browser. Live payment collection is intentionally not enabled until you configure Stripe. Card details are handled on Stripe-hosted Checkout; do not collect or store card numbers in this site.

// Optional Stripe Checkout backend. Never put secret keys in public/app.js.
require("dotenv").config();
const express = require("express");
const Stripe = require("stripe");
const path = require("path");
const app = express();
const stripe = process.env.STRIPE_SECRET_KEY ? Stripe(process.env.STRIPE_SECRET_KEY) : null;
const catalog = {
  1:{name:"Professional Stainless Stock Pot",unit_amount:6400},
  2:{name:"Nonstick Fry Pan",unit_amount:3200},
  3:{name:"Chef's Knife",unit_amount:2800},
  4:{name:"Wood Cutting Board",unit_amount:2400},
  5:{name:"Food Storage Container Set",unit_amount:3900},
  6:{name:"Stainless Serving Tongs",unit_amount:1200},
  7:{name:"Commercial Mixing Bowl Set",unit_amount:3500},
  8:{name:"Kitchen Cleaning Kit",unit_amount:2200}
};
app.use(express.json());
app.use(express.static(path.join(__dirname,"public")));
app.post("/api/create-checkout-session",async(req,res)=>{
  if(!stripe)return res.status(503).json({error:"Stripe is not configured"});
  try{
    const line_items=(req.body.items||[]).map(item=>{
      const p=catalog[Number(item.id)];
      if(!p)throw new Error("Unknown product");
      const quantity=Math.max(1,Math.min(50,Number(item.quantity)||1));
      return {price_data:{currency:"usd",product_data:{name:p.name},unit_amount:p.unit_amount},quantity};
    });
    if(!line_items.length)return res.status(400).json({error:"Cart is empty"});
    const session=await stripe.checkout.sessions.create({
      mode:"payment",line_items,
      success_url:`${process.env.BASE_URL}/?payment=success`,
      cancel_url:`${process.env.BASE_URL}/?payment=cancelled`
    });
    res.json({url:session.url});
  }catch(err){console.error(err);res.status(400).json({error:"Unable to create checkout session"});}
});
const port=process.env.PORT||4242;
app.listen(port,()=>console.log(`Cookpoint website running at http://localhost:${port}`));

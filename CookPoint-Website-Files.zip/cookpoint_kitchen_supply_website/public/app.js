const products = [
 {id:1,name:"Professional Stainless Stock Pot",category:"Cookware & Bakeware",price:64.00,tag:"BESTSELLER",img:"https://images.unsplash.com/photo-1584990347449-a9b5d6f5b4f7?auto=format&fit=crop&w=800&q=80"},
 {id:2,name:"Nonstick Fry Pan",category:"Cookware & Bakeware",price:32.00,tag:"EVERYDAY",img:"https://images.unsplash.com/photo-1592156328697-5b3b6c0f1f8b?auto=format&fit=crop&w=800&q=80"},
 {id:3,name:"Chef's Knife",category:"Food Preparation",price:28.00,tag:"ESSENTIAL",img:"https://images.unsplash.com/photo-1593618998160-e34014e67546?auto=format&fit=crop&w=800&q=80"},
 {id:4,name:"Wood Cutting Board",category:"Food Preparation",price:24.00,tag:"PREP",img:"https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=800&q=80"},
 {id:5,name:"Food Storage Container Set",category:"Storage & Organization",price:39.00,tag:"ORGANIZE",img:"https://images.unsplash.com/photo-1603199506016-b9a594b593c0?auto=format&fit=crop&w=800&q=80"},
 {id:6,name:"Stainless Serving Tongs",category:"Serving Tools",price:12.00,tag:"SERVICE",img:"https://images.unsplash.com/photo-1556911220-bff31c812dba?auto=format&fit=crop&w=800&q=80"},
 {id:7,name:"Commercial Mixing Bowl Set",category:"Food Preparation",price:35.00,tag:"VERSATILE",img:"https://images.unsplash.com/photo-1518779578993-ec3579fee39f?auto=format&fit=crop&w=800&q=80"},
 {id:8,name:"Kitchen Cleaning Kit",category:"Cleaning & Sanitation",price:22.00,tag:"CLEAN",img:"https://images.unsplash.com/photo-1585421514284-efb74c2b69ba?auto=format&fit=crop&w=800&q=80"}
];
const money=n=>new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"}).format(n);
let cart=[];
const grid=document.getElementById("productGrid");
function renderProducts(category="All"){
 const list=category==="All"?products:products.filter(p=>p.category===category);
 grid.innerHTML=list.map(p=>`<article class="product-card"><div class="product-image"><img src="${p.img}" alt="${p.name}" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1556911220-bff31c812dba?auto=format&fit=crop&w=800&q=80'"><span class="product-tag">${p.tag}</span></div><div class="product-info"><span class="product-category">${p.category}</span><h3>${p.name}</h3><div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add-btn" aria-label="Add ${p.name} to bag" data-add="${p.id}">+</button></div></div></article>`).join("")||'<p class="no-results">No products in this category yet.</p>';
}
function renderCart(){
 document.getElementById("cartCount").textContent=cart.reduce((s,x)=>s+x.qty,0);
 document.getElementById("cartSubtotal").textContent=money(cart.reduce((s,x)=>s+x.price*x.qty,0));
 const el=document.getElementById("cartItems");
 el.innerHTML=cart.length?cart.map(x=>`<div class="cart-line"><img src="${x.img}" alt=""><div><b>${x.name}</b><small>${money(x.price)} each</small><div class="qty-controls"><button data-qty="${x.id}" data-delta="-1">−</button><span>${x.qty}</span><button data-qty="${x.id}" data-delta="1">+</button></div></div><span class="line-price">${money(x.price*x.qty)}</span></div>`).join(""):'<p class="empty-cart">Your bag is ready for something useful.</p>';
}
function openCart(){document.getElementById("cartDrawer").classList.add("open");document.getElementById("drawerBackdrop").classList.add("open");document.getElementById("cartDrawer").setAttribute("aria-hidden","false")}
function closeCart(){document.getElementById("cartDrawer").classList.remove("open");document.getElementById("drawerBackdrop").classList.remove("open");document.getElementById("cartDrawer").setAttribute("aria-hidden","true")}
document.getElementById("categoryFilters").addEventListener("click",e=>{const b=e.target.closest("[data-category]");if(!b)return;document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");renderProducts(b.dataset.category)});
grid.addEventListener("click",e=>{const b=e.target.closest("[data-add]");if(!b)return;const p=products.find(x=>x.id===Number(b.dataset.add));const item=cart.find(x=>x.id===p.id);item?item.qty++:cart.push({...p,qty:1});renderCart();openCart()});
document.getElementById("cartItems").addEventListener("click",e=>{const b=e.target.closest("[data-qty]");if(!b)return;const item=cart.find(x=>x.id===Number(b.dataset.qty));item.qty+=Number(b.dataset.delta);if(item.qty<=0)cart=cart.filter(x=>x.id!==item.id);renderCart()});
document.getElementById("openCart").addEventListener("click",openCart);document.getElementById("closeCart").addEventListener("click",closeCart);document.getElementById("drawerBackdrop").addEventListener("click",closeCart);
document.getElementById("checkoutBtn").addEventListener("click",async()=>{
 if(!cart.length){alert("Your bag is empty.");return}
 // The backend endpoint is included in server.js. Configure Stripe keys before enabling live payments.
 try{
  const res=await fetch("/api/create-checkout-session",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({items:cart.map(({id,qty})=>({id,quantity:qty}))})});
  if(!res.ok)throw new Error("Payment service is not configured yet.");
  const data=await res.json();if(data.url)window.location=data.url;else throw new Error("Checkout could not be started.");
 }catch(err){alert("Online payment setup is not connected yet. Your cart is working; connect your Stripe account and deploy the included server to accept payments.")}
});
document.getElementById("contactForm").addEventListener("submit",e=>{
 e.preventDefault();const d=new FormData(e.currentTarget);
 const businessEmail="REPLACE_WITH_YOUR_EMAIL";
 if(businessEmail==="REPLACE_WITH_YOUR_EMAIL"){document.getElementById("contactStatus").textContent="Contact form is ready. Add your business email in app.js to send inquiries.";return}
 const subject=encodeURIComponent("Cookpoint website inquiry — "+d.get("topic"));
 const body=encodeURIComponent(`Name: ${d.get("name")}\nEmail: ${d.get("email")}\nTopic: ${d.get("topic")}\n\n${d.get("message")}`);
 window.location.href=`mailto:${businessEmail}?subject=${subject}&body=${body}`;
});
document.getElementById("menuToggle").addEventListener("click",()=>document.getElementById("mainNav").classList.toggle("open"));
document.querySelectorAll("#mainNav a").forEach(a=>a.addEventListener("click",()=>document.getElementById("mainNav").classList.remove("open")));
document.getElementById("year").textContent=new Date().getFullYear();
renderProducts();renderCart();
